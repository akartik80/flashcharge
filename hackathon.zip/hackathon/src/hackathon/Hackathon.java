/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hackathon;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author vaibhav
 */
public class Hackathon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("paytm_normal.csv"));
        
        String headers[] = sc.nextLine().split(",");
        
        //list -> (coupon, %, fixed cashback, max cashback)
        //type -> (recharge anount range -> list)
        HashMap<String, HashMap<String, List<String>>> coupon = new HashMap<>();
        HashMap<String, List<String>> temp_for_water = new HashMap<>();
        HashMap<String, List<String>> rec = new HashMap<>();
        HashMap<String, List<String>> temp_for_electricity = new HashMap<>();
        HashMap<String, List<String>> temp_for_dth = new HashMap<>();
        HashMap<String, List<String>> temp_for_utility = new HashMap<>();
        HashMap<String, List<String>> temp_for_landline = new HashMap<>();
        HashMap<String, List<String>> temp_for_metro = new HashMap<>();
        //list (condition )-> (coupon, %, fixed cashback, max cashback)
        
        HashMap<String, List<String>> hh = new HashMap<>();
        coupon.put("recharge", hh);
        coupon.put("electricity", hh);
        coupon.put("water", hh);
        coupon.put("landline", hh);
        coupon.put("dth", hh);
        coupon.put("metro", hh);
        
        while (sc.hasNextLine()) {
            String h[] = sc.nextLine().split(",");
            if(!h[0].contains("Get")) continue;
            
            h[0] = h[0].toLowerCase();
            //System.out.println(h[0]);
            h[1] = h[1].toLowerCase();
            h[2] = h[2].toLowerCase();
            //System.out.println(h[2]);
            int index = h[0].indexOf("cashback");
            
            String s1 = h[0].substring(0, index-1);
            String s2 = h[0].substring(index + 9);
            
            //for recharges
            if ((h[0].contains("recharge") || h[0].contains("recharges")) && !h[0].contains("metro") && !h[0].contains("dtn")) {
                
                List<String> l = new ArrayList<>();
                
                l.add(h[1]);
                
                if (s1.contains("%")) {
                    int index1 = s1.lastIndexOf(" ");
                    String ss = s1.substring(index1+1);
                    l.add(ss);
                } else if (h[2].contains("%")) {
                    int index1 = h[2].indexOf("%");
                    String ss = h[2].substring(0, index1);
                    index1 = ss.lastIndexOf(" ");
                    ss = ss.substring(index1 + 1);
                    l.add(ss);
                }
                
                if (l.size() == 2) {
                    l.add("-");
                } else {
                    l.add("-");
                    
                    int index1 = s1.lastIndexOf(" ");
                    String ss = s1.substring(index1+1);
                    l.add(ss);
                }
                
                if (h[0].contains("upto")) {
                    int index1 = s1.lastIndexOf(" ");
                    String ss = s1.substring(index1+1);
                    l.add(ss);
                } else if (h[2].contains("upto") || h[2].contains("max")) {
                    if (h[2].contains("rs.")) {
                        int index1 = h[2].indexOf("rs. ");
                        String ss = h[2].substring(index1+4, h[2].indexOf(" ", index1+4));
                        l.add(ss);
                    } else if (h[2].contains("rs ")){
                        int index1 = h[2].indexOf("rs ");
                        String ss = h[2].substring(index1+3, h[2].indexOf(" ", index1+3));
                        l.add(ss);
                    }
                }
                
                if (l.size() < 4) {
                    l.add("-");
                }
                
                String recharge_amt = "";
                
                if (s2.contains("rs. ") || s2.contains("rs ")) {
                    if (s2.contains("rs. ")) {
                        int index1 = s2.indexOf("rs. ");
                        String ss = s2.substring(index1+4, s2.indexOf(" ", index1+4));
                        recharge_amt = ss + "+";
                    } else {
                        int index1 = s2.indexOf("rs ");
                        String ss = s2.substring(index1+3, s2.indexOf(" ", index1+3));
                        recharge_amt = ss + "+";
                    }
                } else {
                    recharge_amt = "0+";
                }
                
                
                
                rec.put(recharge_amt, l);
                
                System.out.println(l);
                
                //System.out.println(recharge_amt + " -> " + coupon.get("recharge").get(recharge_amt));
                
                
            } else if (h[0].contains("water")) {
                //System.out.println(h[1]);
                String condition="";
                String percent_cashback="-";
                String couponz="-";
                String cashback="-";
                String max_cashback="-";
                
                couponz = h[1];
                //System.out.println(h[2]);
                //if(coupon.containsKey("water")) {
                    
                //} else {
                    //System.out.println("entered");
                    int idx = h[0].indexOf("payments");
                    
                    String kk = h[0].substring(idx+9);
                    int i;
                    
                    List<String> tail = new ArrayList<>();
                    if(kk.contains("more") || kk.contains("+")) {
                        String kk1[] = kk.split(" ");
                        
                        for(i=0;i < kk1.length; i++) {
                            if(kk1[i].equals("rs") || kk1[i].equals("rs.")) {
                                break;
                            }
                        }
                        
                        condition = ">=";
                        
                        condition+=kk1[i+1];
                        
                        //coupon filled
                    }  else {
                        condition="-";
                    }
                    
                    if(!s1.contains("%")) {
                        // %age filled
                        //tail.add("-");
                        String kk2[] = s1.split(" ");
                        //System.out.println(s1);
                        for(i=0;i<kk2.length;i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.")) {
                                break;
                            }
                        }

                        max_cashback="-";

                        if(s1.contains("upto")  || s1.contains("max")) {
                            max_cashback = kk2[i+1];
                        }

                        if(h[2].contains("%")) {
                            //System.out.println("now here");
                            System.out.println(h[2]);
                            int idx1 = h[2].indexOf("%");
                            String str = h[2].substring(0, idx1);
                            
                            String yyy[] = str.split(" ");
                            
                            percent_cashback = yyy[yyy.length-1];
                            
                        }
                    } else {
                        int idx1 = h[0].indexOf("%");
                        
                        String kk1 = h[0].substring(0, idx1);
                        
                        String tmp[] = kk1.split(" ");
                        
                        percent_cashback = tmp[tmp.length-1];
                        
                        String kk2[] = h[2].split(" ");
                        
                        for(i=0;i<kk2.length; i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.") ) {
                                break;
                            }
                        }
                        
                        max_cashback = kk2[i+1];
                    }
                    
                    tail.add(condition);
                    tail.add(couponz);
                    tail.add(percent_cashback);
                    tail.add(cashback);
                    tail.add(max_cashback);

                    temp_for_water.put(condition, tail);
                    coupon.put("water", temp_for_water);
                    
                    System.out.println(tail);
                    
            } else if (h[0].contains("electricity")) {
                String condition="";
                String percent_cashback="-";
                String couponz="-";
                String cashback="-";
                String max_cashback="-";
                
                couponz = h[1];
                
                    int idx = -1; 
                    idx = h[0].indexOf("payments");
                    
                    if(idx == -1) {
                        idx = h[0].indexOf("payment");
                    }
                    String kk = h[0].substring(idx+9);
                    int i;
                    
                    List<String> tail = new ArrayList<>();
                    if(kk.contains("more") || kk.contains("+")) {
                        String kk1[] = kk.split(" ");
                        
                        for(i=0;i < kk1.length; i++) {
                            if(kk1[i].equals("rs") || kk1[i].equals("rs.")) {
                                break;
                            }
                        }
                        
                        condition = ">=";
                        
                        condition+=kk1[i+1];
                        
                        //coupon filled
                    }  else {
                        condition="-";
                    }
                    
                    if(!s1.contains("%")) {
                        
                        String kk2[] = s1.split(" ");
                        //System.out.println(s1);
                        for(i=0;i<kk2.length;i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.")) {
                                break;
                            }
                        }

                        max_cashback="-";

                        if(s1.contains("upto") || s1.contains("max")) {
                            max_cashback = kk2[i+1];
                        }

                        //percent_cashback = yy2[yy2.length-1];
                        
                        if(h[2].contains("%")) {
                            //System.out.println("now here");
                            System.out.println(h[2]);
                            int idx1 = h[2].indexOf("%");
                            String str = h[2].substring(0, idx1);
                            
                            String yyy[] = str.split(" ");
                            
                            percent_cashback = yyy[yyy.length-1];
                            
                        }
                    } else {
                        int idx1 = h[0].indexOf("%");
                        
                        String kk1 = h[0].substring(0, idx1);
                        
                        String tmp[] = kk1.split(" ");
                        
                        percent_cashback = tmp[tmp.length-1];
                        
                        String kk2[] = h[2].split(" ");
                        
                        for(i=0;i<kk2.length; i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.") ) {
                                break;
                            }
                        }
                        
                        max_cashback = kk2[i+1];
                    }
                    
                    tail.add(condition);
                    tail.add(couponz);
                    tail.add(percent_cashback);
                    tail.add(cashback);
                    tail.add(max_cashback);

                    temp_for_electricity.put(condition, tail);
                    coupon.put("electricity", temp_for_electricity);
                    
                    System.out.println(tail);
                
            } else if (h[0].contains("landline")) {
                //System.out.println(h[1]);
                String condition="";
                String percent_cashback="-";
                String couponz="-";
                String cashback="-";
                String max_cashback="-";
                
                couponz = h[1];
                //System.out.println(h[2]);
                //if(coupon.containsKey("water")) {
                    
                //} else {
                    //System.out.println("entered");
                    int idx = h[0].indexOf("payments");
                    
                    String kk = h[0].substring(idx+9);
                    int i;
                    
                    List<String> tail = new ArrayList<>();
                    if(kk.contains("more") || kk.contains("+")) {
                        String kk1[] = kk.split(" ");
                        
                        for(i=0;i < kk1.length; i++) {
                            if(kk1[i].equals("rs") || kk1[i].equals("rs.")) {
                                break;
                            }
                        }
                        
                        condition = ">=";
                        
                        condition+=kk1[i+1];
                        
                        //coupon filled
                    }  else {
                        condition="-";
                    }
                    
                    if(!s1.contains("%")) {
                        // %age filled
                        //tail.add("-");
                        String kk2[] = s1.split(" ");
                        //System.out.println(s1);
                        for(i=0;i<kk2.length;i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.")) {
                                break;
                            }
                        }

                        max_cashback="-";

                        if(s1.contains("upto")  || s1.contains("max")) {
                            max_cashback = kk2[i+1];
                        }

                        if(h[2].contains("%")) {
                            //System.out.println("now here");
                            System.out.println(h[2]);
                            int idx1 = h[2].indexOf("%");
                            String str = h[2].substring(0, idx1);
                            
                            String yyy[] = str.split(" ");
                            
                            percent_cashback = yyy[yyy.length-1];
                            
                        }
                    } else {
                        int idx1 = h[0].indexOf("%");
                        
                        String kk1 = h[0].substring(0, idx1);
                        
                        String tmp[] = kk1.split(" ");
                        
                        percent_cashback = tmp[tmp.length-1];
                        
                        String kk2[] = h[2].split(" ");
                        
                        for(i=0;i<kk2.length; i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.") ) {
                                break;
                            }
                        }
                        
                        max_cashback = kk2[i+1];
                    } 
                    
                    tail.add(condition);
                    tail.add(couponz);
                    tail.add(percent_cashback);
                    tail.add(cashback);
                    tail.add(max_cashback);

                    temp_for_landline.put(condition, tail);
                    coupon.put("water", temp_for_landline);
                    
                    System.out.println(tail);
                
            } else if (h[0].contains("metro")) {
                String condition="";
                String percent_cashback="-";
                String couponz="-";
                String cashback="-";
                String max_cashback="-";
                
                couponz = h[1];
                //System.out.println("hre entered");
                    int idx = h[0].indexOf("payments");
                    
                    String kk = h[0].substring(idx+9);
                    int i;
                    
                    List<String> tail = new ArrayList<>();
                    if(kk.contains("more") || kk.contains("+")) {
                        String kk1[] = kk.split(" ");
                        
                        for(i=0;i < kk1.length; i++) {
                            if(kk1[i].equals("rs") || kk1[i].equals("rs.")) {
                                break;
                            }
                        }
                        
                        condition = ">=";
                        
                        condition+=kk1[i+1];
                        
                        //coupon filled
                    }  else {
                        condition="-";
                    }
                    
                    if(!s1.contains("%")) {
                        // %age filled
                        //tail.add("-");
                        String kk2[] = s1.split(" ");
                        //System.out.println(s1);
                        for(i=0;i<kk2.length;i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.")) {
                                break;
                            }
                        }

                        max_cashback="-";

                        if(s1.contains("upto") || s1.contains("max")) {
                            max_cashback = kk2[i+1];
                        }

                        if(h[2].contains("%")) {
                            //System.out.println("now here");
                            System.out.println(h[2]);
                            int idx1 = h[2].indexOf("%");
                            String str = h[2].substring(0, idx1);
                            
                            String yyy[] = str.split(" ");
                            
                            percent_cashback = yyy[yyy.length-1];
                            
                        }
                    } else {
                        int idx1 = h[0].indexOf("%");
                        
                        String kk1 = h[0].substring(0, idx1);
                        
                        String tmp[] = kk1.split(" ");
                        
                        percent_cashback = tmp[tmp.length-1];
                        
                        String kk2[] = h[2].split(" ");
                        
                        for(i=0;i<kk2.length; i++) {
                            if(kk2[i].equals("rs") || kk2[i].equals("rs.") ) {
                                break;
                            }
                        }
                        
                        max_cashback = kk2[i+1];
                    }
                    
                    tail.add(condition);
                    tail.add(couponz);
                    tail.add(percent_cashback);
                    tail.add(cashback);
                    tail.add(max_cashback);

                    temp_for_metro.put(condition, tail);
                    coupon.put("water", temp_for_metro);
                    
                    System.out.println(tail);
            } else if (h[0].contains("dth")) {
                
            }

        }
        
        System.out.println("for recharges : ");
        
        for (String s : coupon.get("recharge").keySet()) {
            System.out.println(s + " -> " + coupon.get("recharge").get(s));
        }
        
        sc.close();
        
        sc = new Scanner(new File("paytm_2.csv"));
        
        headers = sc.nextLine().split(",");
        
        //operator -> (day, recharge amount, coupon_code, cashback)
        HashMap<String, List<String>> days_offer = new HashMap<>();
        
        while (sc.hasNextLine()) {
            String temp = sc.nextLine();
            String h[] = temp.split(",");
            
            h[0] = h[0].toLowerCase();
            h[1] = h[1].toLowerCase();
            h[2] = h[2].toLowerCase();
            
            String h1[] = h[0].split(" ");
            
            List<String> l = new ArrayList<>();
            
            l.add(h1[1]);
            
            int index = h[2].lastIndexOf("rs ");
            
            String ss = h[2].substring(index+3, h[2].indexOf(" ", index+3));
            l.add(ss + "+");
            l.add(h[1].substring(1, h[1].length()-1).toUpperCase());
            
//            index = h[2].indexOf("Rs ");
//            
//            ss = h[2].substring(index+3, h[2].indexOf(" ", index+3));
//            l.add(ss + "+");
            
            index = h[2].indexOf("cashback");
            
            ss = h[2].substring(5, index-1);
            l.add(ss);
            
            days_offer.put(h1[0].substring(1), l);
        }
        
        for (String s : days_offer.keySet()) {
            System.out.println(s + " -> " + days_offer.get(s));
        }
        sc.close();
    }
    
}
